package bcu.cmp5332.librarysystem.model;

import bcu.cmp5332.librarysystem.main.LibraryException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Patron{

	private int id;
	private String name;
	private String phone;
	private final List<Book> books = new ArrayList<>();


	// TODO: implement constructor here
	public Patron(int id, String name, String phone) {
		super();
		this.id = id;
		this.name = name;
		this.phone = phone;
	}


	public void borrowBook(Book book, LocalDate dueDate) throws LibraryException {
		
		/*
		 * Check if the book is currently on loan (check how you would find this out, if
		 * the book is on loan throw a library exception) Create a new Loan Object Set
		 * the new loan object to be the books loan (book.setLoan(loan)) Add book to the
		 * patron object (addBook(book))
		 */


		if(book.isOnLoan()) {
			throw new LibraryException("This book is reservered");
		}
		Loan loan = new Loan(null, book, dueDate, dueDate);
		book.setLoan(loan);
		addBook(book);		System.out.println("Book #" +  book.getId() + " added.");
 
	}
	
	public void returnBook(Book book, LocalDate dueDate) throws LibraryException {
		if(book.isOnLoan()) {
			throw new LibraryException("This book is reservered ");
		}
		Book ReturnBook = new Book(id, name, name, name);
		book.returnToLibrary();
		System.out.println("we");
			
		}
	


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDetailsLong() {
		// TODO: implementation here
		return null;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void renewBook(Book book, LocalDate dueDate) throws LibraryException {
		// TODO: implementation here
	}

	public void returnBook(Book book) throws LibraryException {
		// TODO: implementation here
		book.returnBook(id);
		}

	public void addBook(Book book) {
		// TODO: implementation here / done 
		books.add(book);
		
	}


	public String getDetailsShort() {
		return "Patron #" + id + " - " + name;
	}

}

