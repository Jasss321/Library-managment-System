package bcu.cmp5332.librarysystem.commands;

import java.time.LocalDate;

import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Patron;

public class AddPatron implements Command {

	private final String name;
	private final String phone;

	public AddPatron(String name, String phone) {
		this.name = name;
		this.phone = phone;
	}

	@Override
	public void execute(Library library, LocalDate currentDate) throws LibraryException {

		int ID = 0;
		if (library.getPatrons().size() > 0) {
			int lastIndex = library.getPatrons().size() - 1;
			ID = library.getPatrons().get(lastIndex).getId();

		}
		Patron patron = new Patron(++ID, name, phone);
		library.addPatron(patron);
		System.out.println("Patron #" + patron.getId() + " added.");

	}
}
