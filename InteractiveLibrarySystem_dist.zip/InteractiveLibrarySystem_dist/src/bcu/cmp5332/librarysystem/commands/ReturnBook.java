package bcu.cmp5332.librarysystem.commands;


import java.time.LocalDate;

import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Patron;


public class ReturnBook implements Command {
	private final Integer patronId;
	private final Integer bookId;

	public ReturnBook(Integer patronId, Integer bookId) {
		this.patronId = patronId;
		this.bookId = bookId;
	}
	

	@Override
	public void execute(Library library, LocalDate currentDate) throws LibraryException {
		
		Book book = library.getBookByID(bookId);
		Patron patron = library.getPatronByID(patronId);
		patron.returnBook(book);
		
	}
	

}
