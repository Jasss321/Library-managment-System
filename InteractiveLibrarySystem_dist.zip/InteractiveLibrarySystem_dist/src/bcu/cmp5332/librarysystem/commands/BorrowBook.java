package bcu.cmp5332.librarysystem.commands;

import java.time.LocalDate;

import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Patron;

public class BorrowBook implements Command {
	private final Integer patronId;
	private final Integer bookId;

	public BorrowBook(Integer patronId, Integer bookId) {
		this.patronId = patronId;
		this.bookId = bookId;
	}

	@Override
	public void execute(Library library, LocalDate currentDate) throws LibraryException {
		// Verify patron exists
		// Verify book exists
		// Then get the patron if it does
		// Hint: Create book object and check
		// Use new book object and add to patron list of books
		// E.g. patrnObject.getBooks().add(bookObj);
		
		LocalDate dueDate = currentDate ; // make sure to complete it and put a dueDate in. 
		Patron patron = library.getPatronByID(patronId);
		Book book = library.getBookByID(bookId); 
		patron.borrowBook(book, dueDate);

		//For return a book (differnt command):
		
		//get the patron
		//try delete the book id from the list of books in books array

	}
}
